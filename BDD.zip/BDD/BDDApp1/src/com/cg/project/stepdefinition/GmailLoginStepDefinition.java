package com.cg.project.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GmailLoginStepDefinition {
	@Given("^User is on Google HomePage$")
	public void user_is_on_Google_HomePage() throws Throwable {
	    throw new PendingException();
	}
	@When("^User search for 'Gmail'$")
	public void user_search_for_Gmail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^All links should display with 'Gmail'$")
	public void all_links_should_display_with_Gmail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^User is on Google searchResultPage$")
	public void user_is_on_Google_searchResultPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User clicks the link 'www\\.google\\.com/gmail'$")
	public void user_clicks_the_link_www_google_com_gmail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'www\\.google\\.com/gmail' login page should open$")
	public void www_google_com_gmail_login_page_should_open() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^User is on GmailLoginPage$")
	public void user_is_on_GmailLoginPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters valid 'emailId' and 'password'$")
	public void user_enters_valid_emailId_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'mail\\.google\\.com/inbox' page should open$")
	public void mail_google_com_inbox_page_should_open() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters invalid 'emailId' or 'password'$")
	public void user_enters_invalid_emailId_or_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'www\\.google\\.com/gmail' login page should open with error message$")
	public void www_google_com_gmail_login_page_should_open_with_error_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
