package com.cg.project.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleSearchStepDefinition {
	@Given("^User is on Google HomePage$")
	public void user_is_on_Google_HomePage() throws Throwable {
	    throw new PendingException();
	}

	@When("^User search for 'Agile Methodology'$")
	public void user_search_for_Agile_Methodology() throws Throwable {
	    throw new PendingException();
	}

	@Then("^All links should display with 'Agile Methodology'$")
	public void all_links_should_display_with_Agile_Methodology() throws Throwable {
	    throw new PendingException();
	}
}
