package com.cg.payroll.stepdefinition;

public class PayrollRegistrationStepDefinition {

}
