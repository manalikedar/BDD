package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubLoginStepDefinition {
	WebDriver driver;
	LoginPage loginPage;
	@Given("^User is on 'www\\.github\\.com/login'page$")
	public void user_is_on_www_github_com_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\159944_Sushant_Dey\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.get("https://www.github.com/login");
	    loginPage=PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User enters valid 'emailId' and valid 'password'$")
	public void user_enters_valid_emailId_and_valid_password() throws Throwable {
		/*By usernameField = By.name("login");
		   WebElement username = driver.findElement(usernameField);
		   username.sendKeys("sushantdey");
		By passwordField = By.name("password");
		   WebElement password = driver.findElement(passwordField);
		   password.sendKeys("Sushant@123");
		By submitField = By.name("commit");
			WebElement submit = driver.findElement(submitField);
			submit.submit();*/
		loginPage.setUsername("sushantdey");
		loginPage.setPassword("Sushant@123");
		loginPage.clickSignIn();
	}

	@Then("^User dashboard page should appear$")
	public void user_dashboard_page_should_appear() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "GitHub";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@When("^User enters invalid 'username' and valid 'password'$")
	public void user_enters_invalid_username_and_valid_password() throws Throwable {
		/*By usernameField = By.name("login");
		   WebElement username = driver.findElement(usernameField);
		   username.sendKeys("abc");
		By passwordField = By.name("password");
		   WebElement password = driver.findElement(passwordField);
		   password.sendKeys("Sushant@123");
		By submitField = By.name("commit");
			WebElement submit = driver.findElement(submitField);
			submit.submit();*/
		loginPage.setUsername("sushant");
		loginPage.setPassword("Sushant@123");
		loginPage.clickSignIn();
	}

	@Then("^'www\\.github\\.com/login' page should open with error message$")
	public void www_github_com_login_page_should_open_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
	    String expectedTitle = "Sign in to GitHub � GitHub";
	    Assert.assertEquals(expectedTitle, actualTitle);
	    driver.close();
	}

	@When("^User enters valid 'username' and invalid 'password'$")
	public void user_enters_valid_username_and_invalid_password() throws Throwable {
		/*By usernameField = By.name("login");
		   WebElement username = driver.findElement(usernameField);
		   username.sendKeys("sushantdey");
		By passwordField = By.name("password");
		   WebElement password = driver.findElement(passwordField);
		   password.sendKeys("Sushant");
		By submitField = By.name("commit");
			WebElement submit = driver.findElement(submitField);
			submit.submit();*/
		loginPage.setUsername("sushantdey");
		loginPage.setPassword("Sushant");
		loginPage.clickSignIn();
	}
}
